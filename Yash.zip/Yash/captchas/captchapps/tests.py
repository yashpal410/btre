from django.test import TestCase
from capt import create_random_captcha_text
import unittest
import re
# Create your tests here.
class SimpleTest(unittest.TestCase):
	
	def test(self):
		x=create_random_captcha_text()
		y = re.findall('[a-zA-z0-9]',x)
		self.assertEqual(len(y),len(x))
	

if __name__ == '__main__':
	unittest.main()

