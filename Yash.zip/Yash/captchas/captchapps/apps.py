from django.apps import AppConfig


class CaptchappsConfig(AppConfig):
    name = 'captchapps'
